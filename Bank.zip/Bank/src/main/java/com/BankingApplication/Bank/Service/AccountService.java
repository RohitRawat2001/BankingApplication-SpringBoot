package com.BankingApplication.Bank.Service;

import com.BankingApplication.Bank.DTO.AccountDTO;
import com.BankingApplication.Bank.Entity.Account;
import com.BankingApplication.Bank.Repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public Account createAccount(Account account){
       return  accountRepository.save(account);
    }

// optional is like that it can store objects and does not contain null directly
    public Optional<Account>  getAccountDetails(Long id){
        return accountRepository.findById(id);
    }



// deposit amount to balance
    public Account deposit(Long id, double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }

        Account account = getAccountDetails(id)
                .orElseThrow(() -> new RuntimeException("Account not found"));

        account.setBalance(account.getBalance() + amount);
        return accountRepository.save(account);
    }

// withdraw amount to balance
    public Account withdraw(Long id, double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }

        Account account = getAccountDetails(id)
                .orElseThrow(() -> new RuntimeException("Account not found"));

        if (account.getBalance() < amount) {
            throw new RuntimeException("Insufficient funds");
        }

        account.setBalance(account.getBalance() - amount);
        return accountRepository.save(account);
    }

//    // Deposit amount to balance using AccountDTO
//    public AccountDTO deposit(Long id, AccountDTO accountDTO) {
//        double amount = accountDTO.getAmount();
//
//        if (amount <= 0) {
//            throw new IllegalArgumentException("Amount must be positive");
//        }
//
//        Account account = getAccountDetails(id)
//                .orElseThrow(() -> new RuntimeException("Account not found"));
//
//        account.setBalance(account.getBalance() + amount);
//        accountRepository.save(account);
//
//        // Prepare and return the updated AccountDTO
//        AccountDTO updatedAccountDTO = new AccountDTO();
//        updatedAccountDTO.setAccountHolderName(account.getAccountHolderName());
//        updatedAccountDTO.setBalance(account.getBalance());
//        updatedAccountDTO.setAmount(amount); // Although this field may be redundant after deposit
//        return updatedAccountDTO;
//    }
//
//    // Withdraw amount from balance using AccountDTO
//    public AccountDTO withdraw(Long id, AccountDTO accountDTO) {
//        double amount = accountDTO.getAmount();
//
//        if (amount <= 0) {
//            throw new IllegalArgumentException("Amount must be positive");
//        }
//
//        Account account = getAccountDetails(id)
//                .orElseThrow(() -> new RuntimeException("Account not found"));
//
//        if (account.getBalance() < amount) {
//            throw new RuntimeException("Insufficient funds");
//        }
//
//        account.setBalance(account.getBalance() - amount);
//        accountRepository.save(account);
//
//        // Prepare and return the updated AccountDTO
//        AccountDTO updatedAccountDTO = new AccountDTO();
//        updatedAccountDTO.setAccountHolderName(account.getAccountHolderName());
//        updatedAccountDTO.setBalance(account.getBalance());
//        updatedAccountDTO.setAmount(amount); // Although this field may be redundant after withdrawal
//        return updatedAccountDTO;
//    }
}
